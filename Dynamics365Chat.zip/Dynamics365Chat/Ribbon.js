﻿///script/Ribbon.js
function showButton()
{
    debugger;
    var chatimg = window.parent.document.getElementById("chatimg")
    if (chatimg == null || chatimg == undefined) {
        var url = Xrm.Page.context.getClientUrl() + '/WebResources/sav_/WS/Chat.png';
        var element = window.parent.document.getElementById("navTabGroupDiv");//.getElementById("navTabGroupDiv");
        if (element != undefined) {
            //var child = element.children[10];
            var para = document.createElement("img");
            para.id = "chatimg"
            para.alt = "Openchat";
            para.src = url;
            para.style.float = "right";
            para.style.height = "30px";
	    para.style.margin-top = "10px";
            para.onclick = function () {
                var webResource = 'sav_/WS/Chat.html';
                Xrm.Utility.openWebResource(webResource, null);
            };
            //if (child != undefined)
            //    element.insertBefore(para, child);
            //else
                element.appendChild(para);
            var Relement = window.parent.document.getElementsByClassName("navTabFiller");
            if (Relement!=undefined && Relement.length > 0)
                Relement[0].remove();
        }
    }
}
