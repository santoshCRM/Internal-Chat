﻿///script/Chat.js


var iconDiv;
var chatdiv;
var headerDiv;
var chatIDiv;
var lstDate;
var _sOrgName = "";
function Openwindow() {
   // debugger;
    iconDiv = document.getElementById("iconDiv");
    chatdiv = document.getElementById("chatDiv");
    headerDiv = document.getElementById("headerDiv");
    chatIDiv = document.getElementById("chatIDiv");
    iconDiv.style.display = 'none';
    headerDiv.style.display = 'block';
    chatdiv.style.display = 'block';
    chatIDiv.style.display = 'block';
    onLoad();
}
function Closewindow() {
  //  debugger;
    iconDiv = document.getElementById("iconDiv");
    chatdiv = document.getElementById("chatDiv");
    headerDiv = document.getElementById("headerDiv");
    chatIDiv = document.getElementById("chatIDiv");
    iconDiv.style.display = 'block';
    headerDiv.style.display = 'none';
    chatdiv.style.display = 'none';
    chatIDiv.style.display = 'none';

}
//reterive all chat
function onLoad() {
    var fetchXml = "<fetch version='1.0' output-format='xml-platform' top='100' mapping='logical' distinct='false'>" +
    "<entity name='sav_chat'>" +
      "<attribute name='sav_chatid' />" +
      "<attribute name='sav_name' />" +
      "<attribute name='createdon' />" +
      "<attribute name='createdby' />" +
      "<attribute name='sav_content' />" +
      "<order attribute='createdon' descending='false' />"
    if (lstDate != undefined) {
        fetchXml = fetchXml + "<filter type='and'>" +
        "<condition attribute='createdon' operator='on-or-after' value='"+lstDate+"' />" +
      "</filter>"
    }
    fetchXml = fetchXml + "</entity> </fetch>";
    retrieveDatabyFetch(fetchXml);
    lstDate = getDateTime();
    chatDiv = document.getElementById("chatDiv");
    if (chatDiv != undefined)
        chatDiv.scrollTop = chatDiv.scrollHeight;
    document.getElementById("chattxt").focus();
   
}
function retrieveDatabyFetch(fetchXml) {
    // debugger;
    var serverUrl = window.parent.Xrm.Page.context.getClientUrl();
    _oService = new FetchUtil(_sOrgName, serverUrl);
    var results = _oService.Fetch(fetchXml);
    if (results.length > 0) {
        readRecordsOnSuccess(results);
    }
}
function readRecordsOnSuccess(data) {
    var outdivId = document.getElementById("chatDiv");
    var oTable = document.getElementById("configGrid");

    if (oTable != null) {
        oTable.innerHTML = "";
        var oTBody = document.createElement("tbody");
        // Loop through the retrieved records
        for (var indx = 0; indx < data.length; indx++) {
            if (data[indx].attributes.sav_content != null) {

                if (data[indx].attributes.sav_content != undefined) {
                    var oTRowAdd = document.createElement("tr");

                    var oTRowTDAdd = document.createElement("td");
                    setText(oTRowTDAdd, data[indx].attributes.createdby.formattedValue);
                    setText(oTRowTDAdd, ": ");
                    setText(oTRowTDAdd, data[indx].attributes.createdon.formattedValue);
                    oTRowTDAdd.className = 'oTRowTDAdd'
                    oTRowAdd.appendChild(oTRowTDAdd);

                    var oTRowTDCon = document.createElement("td");
                    setText(oTRowTDCon, data[indx].attributes.sav_content.value);
                    oTRowTDCon.className = 'oTRowTDCon'
                    oTRowAdd.appendChild(oTRowTDCon);

                    oTBody.appendChild(oTRowAdd);
                }
              
            }
        }
        oTable.appendChild(oTBody);
        outdivId.appendChild(oTable);
    }

}
function setText(element, text) {
    if (typeof element.innerText != "undefined") {
        element.innerText =element.innerText+ text;
    }
    else { element.textContent =element.textContent+ text; }
}

function createChat()
{
  //  debugger;
    var sav_chat = {};
    sav_chat.sav_name = "Chat";
    sav_chat.sav_content = document.getElementById("chattxt").value;
    if (sav_chat.sav_content == "") {
        return;
    }
    var serverUrl = window.parent.Xrm.Page.context.getClientUrl();
    _oService = new FetchUtil(_sOrgName, serverUrl);
    var results = _oService.createRecord(sav_chat, "sav_chat", function (sav_chat) { }, errorHandler,false);
    onLoad();
    document.getElementById("chattxt").value = "";
  
}
function errorHandler(error) {
    writeMessage(error.message);
}


function getDateTime()
{
    var currentdate = new Date();
    return currentdate.getFullYear() + "-" + currentdate.getMonth() + "-" + currentdate.getDay() + " " + currentdate.getHours() + ":" + currentdate.getMinutes() + ":" + currentdate.getSeconds();
}
function openView()
{
    var serverUrl = window.parent.Xrm.Page.context.getClientUrl();
    var viewUrl= serverUrl+"/main.aspx?etn=sav_chat&pagetype=entitylist&viewid={EDC7E7A7-ED21-430B-959A-B0764CCB2FE7}&viewtype=1039&navbar=off&cmdbar=true";
    window.open(viewUrl);
}
